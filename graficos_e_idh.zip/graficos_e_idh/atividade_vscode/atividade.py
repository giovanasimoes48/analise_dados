import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path

BASE = Path(__file__).resolve().parent
CSV = BASE / "Tabela4.csv"
OUT = BASE / "graficos"
OUT.mkdir(exist_ok=True)

sns.set_theme(style="whitegrid")

df = pd.read_csv(CSV, sep=";", decimal=",", encoding="cp1252")
df = df.dropna(axis=1, how="all")

print("Colunas encontradas:")
print(df.columns.tolist())
print("\nPrimeiras linhas:")
print(df.head())

colunas_a2 = [
    "uf_regiao", "homem_branca", "homem_preta_parda",
    "mulher_branca", "mulher_preta_parda"
]

if all(c in df.columns for c in colunas_a2):
    regioes = ["Norte", "Nordeste", "Sudeste", "Sul", "Centro-Oeste"]
    reg = df[df["uf_regiao"].isin(regioes)].copy()

    reg["homens"] = (reg["homem_branca"] + reg["homem_preta_parda"]) / 2
    reg["mulheres"] = (reg["mulher_branca"] + reg["mulher_preta_parda"]) / 2

    reg_long = reg.melt(
        id_vars="uf_regiao",
        value_vars=["homens", "mulheres"],
        var_name="sexo",
        value_name="horas"
    )

    fig, ax = plt.subplots(figsize=(9, 5))
    sns.barplot(data=reg_long, x="uf_regiao", y="horas", hue="sexo", ax=ax)
    ax.set_title("Afazeres domésticos por região e sexo")
    ax.set_xlabel("Região")
    ax.set_ylabel("Horas / semana")
    plt.tight_layout()
    fig.savefig(OUT / "atividade_2_afazeres_domesticos.png", dpi=150)
    plt.show()
else:
    print("\nATIVIDADE 2: as colunas esperadas não existem neste CSV.")


def atividade_3(formacao_total, formacao_stem, formacao_saude):
    brasil = pd.DataFrame({
        "area": ["Graduação (total)", "STEM", "Saúde / educação"],
        "homens": [
            formacao_total.loc[
                formacao_total["uf_regiao"] == "Brasil", "total_homens"
            ].item(),
            formacao_stem.loc[
                formacao_stem["uf_regiao"] == "Brasil", "homens"
            ].item(),
            formacao_saude.loc[
                formacao_saude["uf_regiao"] == "Brasil", "homens"
            ].item(),
        ],
        "mulheres": [
            formacao_total.loc[
                formacao_total["uf_regiao"] == "Brasil", "total_mulheres"
            ].item(),
            formacao_stem.loc[
                formacao_stem["uf_regiao"] == "Brasil", "mulheres"
            ].item(),
            formacao_saude.loc[
                formacao_saude["uf_regiao"] == "Brasil", "mulheres"
            ].item(),
        ]
    })

    brasil_long = brasil.melt(
        id_vars="area",
        var_name="sexo",
        value_name="pessoas"
    )

    fig, ax = plt.subplots(figsize=(9, 5))
    sns.barplot(data=brasil_long, x="area", y="pessoas", hue="sexo", ax=ax)
    ax.set_title("Brasil: pessoas com graduação, por área e sexo")
    ax.set_xlabel("Área")
    ax.set_ylabel("Pessoas")
    plt.tight_layout()
    fig.savefig(OUT / "atividade_3_formacao_academica.png", dpi=150)
    plt.show()

if "UF" in df.columns and "2022" in df.columns:
    pop_estado = df[["UF", "2022"]].copy()
    pop_estado["2022"] = pd.to_numeric(pop_estado["2022"], errors="coerce")
    pop_estado = pop_estado.dropna(subset=["2022"])

    ordem = pop_estado.sort_values("2022", ascending=False)

    fig, ax = plt.subplots(figsize=(9, 8))
    sns.barplot(data=ordem, y="UF", x="2022", ax=ax)
    ax.set_title("População 2022 por UF")
    ax.set_xlabel("Habitantes")
    ax.set_ylabel("UF")
    plt.tight_layout()
    fig.savefig(OUT / "atividade_4_populacao_2022.png", dpi=150)
    plt.show()
else:
    print("\nATIVIDADE 4: as colunas UF e 2022 não existem neste CSV.")


anos = [c for c in df.columns if str(c).strip().isdigit()]
variaveis = [c for c in df.columns if c not in anos]

print("\nAnos encontrados para o IDH:", anos)

if anos:
    df_longo = df.melt(
        id_vars=variaveis,
        value_vars=anos,
        var_name="Ano",
        value_name="IDH"
    )

    df_longo["Ano"] = pd.to_numeric(df_longo["Ano"], errors="coerce")
    df_longo["IDH"] = (
        df_longo["IDH"].astype(str)
        .str.replace(",", ".", regex=False)
        .str.strip()
    )
    df_longo["IDH"] = pd.to_numeric(df_longo["IDH"], errors="coerce")
    df_longo = df_longo.dropna(subset=["Ano", "IDH"])


    coluna_uf = next(
        (c for c in ["Sigla", "UF", "uf", "sigla"] if c in df_longo.columns),
        None
    )

    if coluna_uf:
        fig, ax = plt.subplots(figsize=(12, 7))

        for sigla, grupo in df_longo.groupby(coluna_uf):
            grupo = grupo.sort_values("Ano")
            ax.plot(
                grupo["Ano"], grupo["IDH"],
                marker="o", markersize=3, linewidth=1.5,
                label=sigla
            )

        ax.set_title("Evolução do IDH por estado")
        ax.set_xlabel("Ano")
        ax.set_ylabel("IDH")
        ax.set_ylim(0.3, 0.9)
        ax.legend(ncol=3, bbox_to_anchor=(1.02, 1),
                  loc="upper left", title="UF")
        fig.tight_layout()
        fig.savefig(OUT / "idh_evolucao_estados.png", dpi=150)
        plt.show()

        mg = df_longo[
            df_longo[coluna_uf].astype(str).str.upper()
            .isin(["MG", "MINAS GERAIS"])
        ].sort_values("Ano")

        if not mg.empty:
            fig, ax = plt.subplots(figsize=(10, 6))
            ax.plot(
                mg["Ano"], mg["IDH"],
                marker="o", linewidth=2
            )
            ax.set_title("Evolução do IDH de Minas Gerais")
            ax.set_xlabel("Ano")
            ax.set_ylabel("IDH")
            ax.set_ylim(0.3, 0.9)
            plt.tight_layout()
            fig.savefig(OUT / "idh_minas_gerais.png", dpi=150)
            plt.show()
        else:
            print("Não foi encontrada uma linha identificada como MG/Minas Gerais.")
    else:
        print("Não foi encontrada coluna Sigla/UF no arquivo.")
else:
    print("Não foram encontradas colunas de anos para o IDH.")

print("\nATIVIDADE FINALIZADA. Veja a pasta 'graficos'.")
