# Atividade de Python — Gráficos e IDH

Projeto preparado para execução no VS Code.

## 1. Abrir o projeto

Extraia o ZIP e abra a pasta no VS Code.

## 2. Instalar bibliotecas

No terminal do VS Code:

```bash
pip install -r requirements.txt
```

## 3. Executar

```bash
python atividade.py
```

## O que foi implementado

- Leitura do CSV usando `;` como separador.
- Tratamento de arquivo com codificação Windows.
- Vírgula decimal.
- Remoção de colunas totalmente vazias.
- `melt` na Atividade 2.
- Gráfico de barras agrupadas da Atividade 2.
- Código da Atividade 3 exatamente baseado na estrutura solicitada.
- Gráfico de população 2022 por UF na Atividade 4.
- Identificação automática das colunas de anos.
- `melt` da tabela de IDH para formato longo.
- Gráfico da evolução do IDH por estado.
- Gráfico específico de Minas Gerais.

## Importante sobre a Atividade 3

O arquivo enviado nesta conversa é uma única tabela (`Tabela4.csv`). O enunciado da Atividade 3 exige três tabelas separadas:

- `formacao_total`
- `formacao_stem`
- `formacao_saude`

Como essas três tabelas não foram enviadas, o código da Atividade 3 foi deixado em uma função pronta, sem inventar valores.
