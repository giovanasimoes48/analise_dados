# IntelligenceCar

Aplicativo Flutter para cadastro de veículos, registro de manutenções e denúncias, com API Flask e banco MySQL.

## O que foi ajustado nesta entrega

- Identidade visual unificada em azul-marinho, azul e tons claros.
- Login reorganizado e adaptável a telas menores.
- Botão **Registrar denúncia** no painel do veículo.
- Formulário de denúncia conectado ao endpoint já existente `POST /api/denuncias`.
- Endereço da API centralizado em `frontend/lib/services/api_service.dart`, inclusive para cadastro de veículo e painel.
- Endereço do servidor configurável por `--dart-define=API_HOST=...`.

**O backend não foi alterado.** Controllers, models, services, repositories, SQL e configuração do servidor foram mantidos como estavam no ZIP original.

## Requisitos

- Flutter SDK compatível com Dart 3.4 ou superior.
- Python 3.10 ou superior.
- MySQL Server iniciado (pode ser o serviço MySQL do WampServer64).
- MySQL Workbench para executar e administrar o banco.
- VS Code com as extensões Flutter e Dart.

> O MySQL Workbench é o programa cliente/administrador. Ele não inicia o banco sozinho. O serviço MySQL precisa estar iniciado no WampServer64 ou no MySQL Server instalado no Windows. Evite deixar dois serviços MySQL disputando a mesma porta (normalmente 3306).

## 1. Preparar o banco

1. Inicie o serviço MySQL no WampServer64.
2. Abra o MySQL Workbench e conecte ao servidor local (normalmente `127.0.0.1`, porta `3306`).
3. Abra `backend/database/create_database.sql`.
4. Execute o script completo.
5. Confira se o schema `projeto` e as tabelas foram criados.

O script SQL original pode definir usuário e senha próprios para o projeto. Confira as credenciais nele antes de iniciar a API.

## 2. Configurar e iniciar a API (sem alterar o código do backend)

Abra um terminal PowerShell na pasta do projeto:

```powershell
cd backend
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
```

O `app.py` lê `DATABASE_URL` de `backend/.env`. O ZIP original não contém um `.env.example`; crie o arquivo `backend/.env` manualmente. O script SQL deste projeto cria o usuário `usuario`, senha `senha`, e o schema `projeto`; para essa configuração local, use:

```env
DATABASE_URL=mysql+pymysql://usuario:senha@localhost:3306/projeto
```

Se a senha tiver caracteres especiais (como `@`, `#`, `/` ou `:`), use a versão URL-encoded desses caracteres na URL.

Inicie a API:

```powershell
python app.py
```

Teste no navegador: `http://127.0.0.1:5000/`

A resposta esperada é uma mensagem indicando que a API do IntelligenceCar está funcionando.

## 3. Iniciar o Flutter no VS Code

Em outro terminal:

```powershell
cd frontend
flutter doctor
flutter pub get
flutter run -d chrome
```

Para executar no Windows Desktop, se o suporte estiver habilitado:

```powershell
flutter run -d windows
```

Para Android Emulator:

```powershell
flutter run
```

O endereço padrão é selecionado automaticamente:
- Chrome e Windows Desktop: `http://127.0.0.1:5000/api`
- Emulador Android: `http://10.0.2.2:5000/api`

Para celular físico, conecte celular e computador à mesma rede Wi-Fi, descubra o IPv4 do computador (`ipconfig`) e execute, por exemplo:

```powershell
flutter run --dart-define=API_HOST=192.168.0.10
```

Troque `192.168.0.10` pelo IPv4 real do computador. Libere a porta TCP 5000 no Firewall do Windows para a rede privada. Não use `127.0.0.1` no celular físico: esse endereço aponta para o próprio celular.

## 4. Ordem correta para testar

1. Inicie MySQL no WampServer64.
2. Confira o banco `projeto` no Workbench.
3. Inicie a API Flask na pasta `backend`.
4. Confirme que `http://127.0.0.1:5000/` responde.
5. Inicie o Flutter na pasta `frontend`.
6. Cadastre um usuário, faça login e cadastre um veículo.
7. Teste manutenção e o botão **Registrar denúncia**.

## 5. Sobre o formulário de denúncia

O formulário envia os campos que o backend original já espera:

- `usuario_id`
- `veiculo_id` (quando há veículo associado)
- `placa`
- `tipo` (um dos valores aceitos pelo backend)
- `descricao` (mínimo de 20 caracteres)

O registro é criado com o status inicial definido pelo próprio backend. Não foi criada tabela, rota ou regra de negócio nova.

## 6. Diagnóstico rápido de conexão

| Sintoma | O que conferir |
|---|---|
| `Não consegui falar com o servidor` | API Flask está rodando na porta 5000? |
| Chrome não conecta | Abra `http://127.0.0.1:5000/` no mesmo computador. |
| Android Emulator não conecta | O endereço deve ser `10.0.2.2`, não `127.0.0.1`. |
| Celular físico não conecta | Use `--dart-define=API_HOST=IP_DO_PC` e libere a porta 5000 no firewall. |
| API inicia, mas dá erro de banco | Serviço MySQL ativo? Porta, usuário, senha e schema conferem com `DATABASE_URL`? |
| Porta 3306 ocupada | Verifique se WampServer e outro MySQL Server estão ativos ao mesmo tempo. |
| `flutter pub get` falha | Confira `flutter doctor`, conexão com internet e versão do Flutter/Dart. |

### Limite importante

WampServer64/Workbench cuidam do MySQL; o backend deste projeto é Flask/Python e precisa ser iniciado separadamente. O Flutter não se conecta diretamente ao MySQL: ele chama a API Flask, que acessa o banco.
