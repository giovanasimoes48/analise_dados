import os
import smtplib
from email.message import EmailMessage


def enviar_codigo_recuperacao(destino, codigo):
    """Envia o código por e-mail se o SMTP estiver configurado no .env.

    Sem SMTP_HOST, o código aparece no terminal onde o app.py está rodando
    (modo de desenvolvimento, bom para testar e apresentar o projeto).
    """
    host = os.getenv("SMTP_HOST")
    if not host:
        print(f"[DEV] Código de recuperação de senha para {destino}: {codigo}")
        return

    mensagem = EmailMessage()
    mensagem["Subject"] = "IntelligenceCar - código de recuperação de senha"
    mensagem["From"] = os.getenv("SMTP_FROM") or os.getenv("SMTP_USER", "")
    mensagem["To"] = destino
    mensagem.set_content(
        f"Seu código de recuperação é: {codigo}\n\n"
        "Ele vale por 15 minutos. Se você não pediu isso, ignore este e-mail."
    )

    with smtplib.SMTP(host, int(os.getenv("SMTP_PORT", "587")), timeout=10) as servidor:
        servidor.starttls()
        servidor.login(os.getenv("SMTP_USER", ""), os.getenv("SMTP_PASSWORD", ""))
        servidor.send_message(mensagem)
