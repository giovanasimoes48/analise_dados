import secrets
from datetime import datetime, timedelta

from werkzeug.security import generate_password_hash

from models.recuperacao_senha import RecuperacaoSenha
from models.user import Usuario
from services.email_service import enviar_codigo_recuperacao
from services.usuarios.validacao import validar_email

VALIDADE_MINUTOS = 15
INTERVALO_ENTRE_ENVIOS_SEGUNDOS = 60


MENSAGEM_PADRAO = "Se este e-mail estiver cadastrado, enviamos um código de recuperação."


class SolicitarRecuperacaoService:
    def execute(self, email):
        email = validar_email(email)
        usuario = Usuario.buscar_por_email(email)
        if not usuario:
            return {"message": MENSAGEM_PADRAO}


        ativa = RecuperacaoSenha.buscar_ativa(usuario.id)
        if ativa and (datetime.now() - ativa.data_criacao).total_seconds() < INTERVALO_ENTRE_ENVIOS_SEGUNDOS:
            return {"message": MENSAGEM_PADRAO}

        codigo = f"{secrets.randbelow(1_000_000):06d}"
        RecuperacaoSenha.criar(
            usuario.id,
            generate_password_hash(codigo),
            datetime.now() + timedelta(minutes=VALIDADE_MINUTOS),
        )

        try:
            enviar_codigo_recuperacao(usuario.email, codigo)
        except Exception as erro:
            print(f"[ERRO] Não foi possível enviar o e-mail: {erro}")

        return {"message": MENSAGEM_PADRAO}
