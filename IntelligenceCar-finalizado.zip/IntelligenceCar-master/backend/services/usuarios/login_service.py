from models.user import Usuario


class LoginService:
    def execute(self, email, senha):
        if not email or not senha:
            raise ValueError("Email e senha são obrigatórios.")

        usuario = Usuario.buscar_por_email(email.strip().lower())


        if not usuario or not usuario.verificar_senha(senha):
            raise PermissionError("E-mail ou senha incorretos.")

        return usuario
