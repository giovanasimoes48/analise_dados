from datetime import datetime

from werkzeug.security import check_password_hash

from models.recuperacao_senha import RecuperacaoSenha
from models.user import Usuario
from services.usuarios.validacao import validar_email, validar_senha

MAX_TENTATIVAS = 5
ERRO_CODIGO = "Código inválido ou expirado."


class RecuperarSenhaService:
    """Passo 2 da recuperação: confere o código e grava a nova senha."""

    def execute(self, email, codigo, nova_senha):
        email = validar_email(email)
        if not codigo or not str(codigo).strip():
            raise ValueError("Informe o código recebido.")
        validar_senha(nova_senha)

        usuario = Usuario.buscar_por_email(email)
        if not usuario:
            raise ValueError(ERRO_CODIGO)

        recuperacao = RecuperacaoSenha.buscar_ativa(usuario.id)
        if not recuperacao or recuperacao.expira_em < datetime.now():
            raise ValueError(ERRO_CODIGO)

        if recuperacao.tentativas >= MAX_TENTATIVAS:
            recuperacao.marcar_como_usada()
            raise ValueError("Muitas tentativas. Peça um novo código.")

        if not check_password_hash(recuperacao.codigo_hash, str(codigo).strip()):
            recuperacao.registrar_tentativa_errada()
            raise ValueError(ERRO_CODIGO)

        usuario.atualizar(nova_senha=nova_senha)  
        recuperacao.marcar_como_usada()
        return {"message": "Senha redefinida com sucesso! Faça login com a nova senha."}
