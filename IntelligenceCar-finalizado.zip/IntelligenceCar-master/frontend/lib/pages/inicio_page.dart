import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import './login_page.dart';
import './calendario_page.dart';
import './historico_page.dart';
import './localizacao_page.dart';
import './registrar_historico_page.dart';
import './denuncia_page.dart';
import '../services/api_service.dart';

// MODELO DE DADOS DO VEÍCULO
class VeiculoModel {
  final int? id;
  final int usuarioId;
  final String marca;
  final String modelo;
  final int ano;
  final String placa;
  final int quilometragem;
  final String? urlImagem;
  final String? ultimaRevisao;
  final List<String> proximasManutencoes;

  VeiculoModel({
    this.id,
    required this.usuarioId,
    required this.marca,
    required this.modelo,
    required this.ano,
    required this.placa,
    required this.quilometragem,
    this.urlImagem,
    this.ultimaRevisao,
    this.proximasManutencoes = const [],
  });

  factory VeiculoModel.fromJson(Map<String, dynamic> json) {
    return VeiculoModel(
      id: json['id'] as int?,
      usuarioId: json['usuario_id'] as int? ?? 0,
      marca: json['marca'] as String? ?? '',
      modelo: json['modelo'] as String? ?? '',
      ano: json['ano'] as int? ?? DateTime.now().year,
      placa: json['placa'] as String? ?? '',
      quilometragem: json['quilometragem'] as int? ?? 0,
      urlImagem: json['url_imagem'] as String? ??
          'https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?w=500',
      ultimaRevisao: json['ultima_revisao'] as String? ?? 'Não informada',
      proximasManutencoes:
          (json['proximas_manutencoes'] as List<dynamic>? ?? [])
              .map((item) => item.toString())
              .toList(),
    );
  }

  Map<String, dynamic> toJsonPost() {
    return {
      'usuario_id': usuarioId,
      'marca': marca,
      'modelo': modelo,
      'ano': ano,
      'placa': placa,
      'quilometragem': quilometragem,
    };
  }
}

class InicioPage extends StatefulWidget {
  final int usuarioId;

  const InicioPage({
    super.key,
    required this.usuarioId,
  });

  @override
  State<InicioPage> createState() => _InicioPageState();
}

class _InicioPageState extends State<InicioPage> {
  VeiculoModel? veiculo;
  bool carregando = false;

  String get apiUrl => '${ApiService.baseUrl}/veiculos';
  String get apiManutencoesUrl => '${ApiService.baseUrl}/manutencoes';

  @override
  void initState() {
    super.initState();
    _carregarDadosDoBackend();
  }

  void _mostrarSnackBar(String mensagem) {
    if (!mounted) return;

    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(content: Text(mensagem)),
      );
  }

  Future<void> _carregarDadosDoBackend() async {
    setState(() => carregando = true);

    try {
      final response = await http.get(
        Uri.parse(apiUrl),
        headers: {'Accept': 'application/json'},
      );

      if (!mounted) return;

      if (response.statusCode == 200) {
        final dynamic dados = jsonDecode(response.body);

        if (dados is! List) {
          _mostrarSnackBar('A resposta da API possui um formato inesperado.');
          return;
        }

        final List<VeiculoModel> veiculos = dados
            .whereType<Map<String, dynamic>>()
            .map(VeiculoModel.fromJson)
            .where((item) => item.usuarioId == widget.usuarioId)
            .toList();

        setState(() {
          veiculo = veiculos.isNotEmpty ? veiculos.first : null;
        });
      } else {
        _mostrarSnackBar('Erro ao carregar veículos: HTTP ${response.statusCode}.');
      }
    } catch (e) {
      _mostrarSnackBar('Erro de conexão com o servidor: $e');
    } finally {
      if (mounted) {
        setState(() => carregando = false);
      }
    }
  }

  Future<void> _cadastrarVeiculoNoBackend(VeiculoModel novoVeiculo) async {
    setState(() => carregando = true);

    try {
      final response = await http.post(
        Uri.parse(apiUrl),
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
        body: jsonEncode(novoVeiculo.toJsonPost()),
      );

      if (!mounted) return;

      if (response.statusCode == 201 || response.statusCode == 200) {
        final dynamic dados = jsonDecode(response.body);

        if (dados is Map<String, dynamic>) {
          setState(() {
            veiculo = VeiculoModel.fromJson(dados);
          });
          _mostrarSnackBar('Veículo cadastrado com sucesso!');
        } else {
          _mostrarSnackBar('O servidor retornou uma resposta inesperada.');
        }
      } else {
        String mensagemErro = 'Não foi possível cadastrar o veículo.';

        try {
          final dynamic erro = jsonDecode(response.body);

          if (erro is Map<String, dynamic>) {
            mensagemErro = erro['error']?.toString() ??
                erro['message']?.toString() ??
                mensagemErro;
          }
        } catch (_) {}

        _mostrarSnackBar('Erro HTTP ${response.statusCode}: $mensagemErro');
      }
    } catch (e) {
      _mostrarSnackBar('Falha na comunicação com a API: $e');
    } finally {
      if (mounted) {
        setState(() => carregando = false);
      }
    }
  }

  // Envia a manutenção para o backend (POST /api/manutencoes).
  // Retorna true se salvou, false se deu algum erro.
  Future<bool> _salvarManutencaoNoBackend(
    String data,
    String oficina,
    String tipo,
    String km,
    String desc,
  ) async {
    if (veiculo?.id == null) {
      _mostrarSnackBar('Cadastre um veículo antes de registrar manutenção.');
      return false;
    }

    // O app usa dd/mm/aaaa, mas o backend espera aaaa-mm-dd
    final partes = data.split('/');
    if (partes.length != 3) {
      _mostrarSnackBar('Data inválida. Use o formato dd/mm/aaaa.');
      return false;
    }
    final dataIso =
        '${partes[2]}-${partes[1].padLeft(2, '0')}-${partes[0].padLeft(2, '0')}';

    final kmNumero = int.tryParse(km.replaceAll(RegExp(r'[^0-9]'), ''));
    if (kmNumero == null) {
      _mostrarSnackBar('Informe o KM atual (apenas números).');
      return false;
    }

    try {
      final response = await http.post(
        Uri.parse(apiManutencoesUrl),
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
        body: jsonEncode({
          'veiculo_id': veiculo!.id,
          'tipo': tipo,
          // O backend não tem campo "oficina", então vai junto na descrição
          'descricao': 'Oficina: $oficina. $desc',
          'data_manutencao': dataIso,
          'quilometragem': kmNumero,
          'valor': 0,
        }),
      );

      if (response.statusCode == 201 || response.statusCode == 200) {
        _mostrarSnackBar('Manutenção salva com sucesso!');
        return true;
      }

      String mensagemErro = 'Não foi possível salvar a manutenção.';
      try {
        final dynamic erro = jsonDecode(response.body);
        if (erro is Map<String, dynamic> && erro['error'] != null) {
          mensagemErro = erro['error'].toString();
        }
      } catch (_) {}
      _mostrarSnackBar('Erro HTTP ${response.statusCode}: $mensagemErro');
      return false;
    } catch (e) {
      _mostrarSnackBar('Falha na comunicação com a API: $e');
      return false;
    }
  }

  void _exibirDialogoCadastro() {
    final formKey = GlobalKey<FormState>();

    final marcaController = TextEditingController();
    final modeloController = TextEditingController();
    final anoController = TextEditingController();
    final placaController = TextEditingController();
    final kmController = TextEditingController();

    showDialog(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('Cadastrar Veículo'),
          content: SingleChildScrollView(
            child: Form(
              key: formKey,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextFormField(
                    controller: marcaController,
                    decoration: const InputDecoration(labelText: 'Marca (ex.: Peugeot)'),
                    validator: (v) => v == null || v.trim().isEmpty ? 'Informe a marca' : null,
                  ),
                  TextFormField(
                    controller: modeloController,
                    decoration: const InputDecoration(labelText: 'Modelo (ex.: 308 THP)'),
                    validator: (v) => v == null || v.trim().isEmpty ? 'Informe o modelo' : null,
                  ),
                  TextFormField(
                    controller: anoController,
                    decoration: const InputDecoration(labelText: 'Ano (ex.: 2013)'),
                    keyboardType: TextInputType.number,
                    validator: (v) {
                      final ano = int.tryParse(v ?? '');
                      if (ano == null || ano < 1900 || ano > DateTime.now().year + 1) {
                        return 'Informe um ano válido';
                      }
                      return null;
                    },
                  ),
                  TextFormField(
                    controller: placaController,
                    decoration: const InputDecoration(labelText: 'Placa'),
                    textCapitalization: TextCapitalization.characters,
                    validator: (v) => v == null || v.trim().isEmpty ? 'Informe a placa' : null,
                  ),
                  TextFormField(
                    controller: kmController,
                    decoration: const InputDecoration(labelText: 'Quilometragem'),
                    keyboardType: TextInputType.number,
                    validator: (v) {
                      final km = int.tryParse(v ?? '');
                      if (km == null || km < 0) {
                        return 'Informe uma quilometragem válida';
                      }
                      return null;
                    },
                  ),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('Cancelar'),
            ),
            ElevatedButton(
              onPressed: () {
                if (!formKey.currentState!.validate()) return;

                final novoVeiculo = VeiculoModel(
                  usuarioId: widget.usuarioId,
                  marca: marcaController.text.trim(),
                  modelo: modeloController.text.trim(),
                  ano: int.parse(anoController.text),
                  placa: placaController.text.trim().toUpperCase(),
                  quilometragem: int.parse(kmController.text),
                );

                Navigator.pop(dialogContext);
                _cadastrarVeiculoNoBackend(novoVeiculo);
              },
              child: const Text('Salvar'),
            ),
          ],
        );
      },
    ).then((_) {
      marcaController.dispose();
      modeloController.dispose();
      anoController.dispose();
      placaController.dispose();
      kmController.dispose();
    });
  }

  @override
  Widget build(BuildContext context) {
    const azulEscuro = Color(0xFF1E3A5F);
    const azulBotao = Color(0xFF4F83CC);
    const cinzaCard = Color(0xFFEAEAEA);

    return Scaffold(
      backgroundColor: const Color(0xFFF4F6F8),
      appBar: AppBar(
        backgroundColor: azulEscuro,
        foregroundColor: Colors.white,
        leading: IconButton(
  icon: const Icon(Icons.arrow_back, color: Colors.white),
  onPressed: () {
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (_) => const LoginPage()),
      (route) => false,
    );
  },
),
        title: const Text('Seu Veículo', style: TextStyle(color: Colors.white)),
        centerTitle: true,

      ),
      body: Container(
        color: Colors.white,
        width: double.infinity,
        height: double.infinity,
        child: carregando
            ? const Center(child: CircularProgressIndicator(color: azulEscuro))
            : RefreshIndicator(
                onRefresh: _carregarDadosDoBackend,
                child: SingleChildScrollView(
                  physics: const AlwaysScrollableScrollPhysics(),
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      if (veiculo == null) ...[
                        const SizedBox(height: 60),
                        const Icon(Icons.directions_car_filled_outlined, size: 80, color: Colors.grey),
                        const SizedBox(height: 16),
                        const Text(
                          'Nenhum veículo cadastrado',
                          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.black54),
                        ),
                        const SizedBox(height: 8),
                        const Text(
                          'Toque no botão abaixo para adicionar as informações do seu carro.',
                          textAlign: TextAlign.center,
                          style: TextStyle(fontSize: 14, color: Colors.grey),
                        ),
                        const SizedBox(height: 60),
                        ElevatedButton(
                          style: ElevatedButton.styleFrom(backgroundColor: azulBotao),
                          onPressed: _exibirDialogoCadastro,
                          child: const Text('Cadastrar Novo Veículo 🚘', style: TextStyle(color: Colors.white)),
                        ),
                      ],
                      if (veiculo != null) ...[
                        Text(
                          '${veiculo!.marca} ${veiculo!.modelo} (${veiculo!.ano})',
                          textAlign: TextAlign.center,
                          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.black),
                        ),
                        Text(
                          'Placa: ${veiculo!.placa}',
                          textAlign: TextAlign.center,
                          style: const TextStyle(fontSize: 16, color: Colors.black),
                        ),
                        const SizedBox(height: 16),
                        Container(
                          padding: const EdgeInsets.all(6),
                          decoration: BoxDecoration(color: azulEscuro, borderRadius: BorderRadius.circular(20)),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(14),
                            child: Image.network(
                              veiculo!.urlImagem ?? '',
                              height: 150,
                              width: double.infinity,
                              fit: BoxFit.cover,
                              errorBuilder: (context, error, stackTrace) {
                                return Container(
                                  height: 150,
                                  color: cinzaCard,
                                  child: const Icon(Icons.broken_image, size: 50, color: Colors.grey),
                                );
                              },
                            ),
                          ),
                        ),
                        const SizedBox(height: 12),
                        Text(
                          'KM Atual: ${veiculo!.quilometragem} km\nÚltima revisão: ${veiculo!.ultimaRevisao}',
                          textAlign: TextAlign.center,
                          style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w500, color: Colors.black),
                        ),
                        const SizedBox(height: 16),
                        Row(
                          children: [
                            Expanded(
                              child: ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: azulBotao,
                                  padding: const EdgeInsets.symmetric(vertical: 12),
                                ),
                                onPressed: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (_) => Scaffold(
                                        appBar: AppBar(title: const Text('Registrar Manutenção')),
                                        body: RegistrarHistoricoPage(
                                          aoSalvar: (d, o, t, k, desc) =>
                                              _salvarManutencaoNoBackend(d, o, t, k, desc),
                                        ),
                                      ),
                                    ),
                                  );
                                },
                                child: const Text('Registrar\nmanutenção', textAlign: TextAlign.center, style: TextStyle(color: Colors.white)),
                              ),
                            ),
                            const SizedBox(width: 16),
                            Expanded(
                              child: ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: cinzaCard,
                                  padding: const EdgeInsets.symmetric(vertical: 20),
                                ),
                                onPressed: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(builder: (_) => HistoricoPage(veiculoId: veiculo!.id!)),
                                  );
                                },
                                child: const Text('Ver Histórico', style: TextStyle(color: Colors.black)),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 20),
                        ElevatedButton.icon(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: cinzaCard,
                            minimumSize: const Size.fromHeight(45),
                          ),
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => Scaffold(
                                  appBar: AppBar(title: const Text('Calendário')),
                                  body: const CalendarioPage(
                                    agendaManutencoes: {},
                                    dataFoco: '15/05/2026',
                                  ),
                                ),
                              ),
                            );
                          },
                          icon: const Icon(Icons.calendar_month),
                          label: const Text('Encontrar Manutenção', style: TextStyle(color: Colors.black)),
                        ),
                        const SizedBox(height: 16),
                        Container(
                          width: double.infinity,
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            border: Border.all(color: azulEscuro, width: 2),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'Próximas manutenções ⚠️',
                                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: Colors.black),
                              ),
                              const SizedBox(height: 8),
                              if (veiculo!.proximasManutencoes.isEmpty)
                                const Text('Nenhuma manutenção pendente.', style: TextStyle(color: Colors.black54)),
                              ...veiculo!.proximasManutencoes.map(
                                (item) => Text('• $item', style: const TextStyle(color: Colors.black)),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 16),
                        ElevatedButton.icon(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: cinzaCard,
                            minimumSize: const Size.fromHeight(45),
                          ),
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (_) => const LocalizacaoPage()),
                            );
                          },
                          icon: const Icon(Icons.location_on),
                          label: const Text('Encontrar oficinas próximas', style: TextStyle(color: Colors.black)),
                        ),
                        const SizedBox(height: 12),
                        SizedBox(
                          width: double.infinity,
                          child: OutlinedButton.icon(
                            style: OutlinedButton.styleFrom(
                              foregroundColor: const Color(0xFF1E3A5F),
                              side: const BorderSide(color: Color(0xFF1E3A5F)),
                              padding: const EdgeInsets.symmetric(vertical: 14),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                            ),
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => DenunciaPage(
                                    usuarioId: widget.usuarioId,
                                    veiculoId: veiculo!.id,
                                    placaInicial: veiculo!.placa,
                                  ),
                                ),
                              );
                            },
                            icon: const Icon(Icons.report_gmailerrorred_outlined),
                            label: const Text('Registrar denúncia'),
                          ),
                        ),
                        const SizedBox(height: 24),
                      ],
                    ],
                  ),
                ),
              ),
      ),
    );
  }
}