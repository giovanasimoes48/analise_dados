import 'package:flutter/material.dart';

import '../services/api_service.dart';

class DenunciaPage extends StatefulWidget {
  final int usuarioId;
  final int? veiculoId;
  final String? placaInicial;

  const DenunciaPage({
    super.key,
    required this.usuarioId,
    this.veiculoId,
    this.placaInicial,
  });

  @override
  State<DenunciaPage> createState() => _DenunciaPageState();
}

class _DenunciaPageState extends State<DenunciaPage> {
  final _formKey = GlobalKey<FormState>();
  final _placaController = TextEditingController();
  final _descricaoController = TextEditingController();
  final _api = ApiService();

  static const _tipos = <String, String>{
    'GOLPE_ANUNCIO_FALSO': 'Golpe em anúncio falso',
    'PAGAMENTO_ANTECIPADO': 'Pedido de pagamento antecipado',
    'CLONAGEM_VEICULO': 'Suspeita de clonagem de veículo',
    'DOCUMENTO_FALSO': 'Documento falso',
    'ADULTERACAO_KM': 'Adulteração de quilometragem',
    'VEICULO_ROUBADO': 'Veículo roubado',
    'OUTRO': 'Outro',
  };

  String _tipo = 'OUTRO';
  bool _enviando = false;

  @override
  void initState() {
    super.initState();
    _placaController.text = widget.placaInicial ?? '';
  }

  @override
  void dispose() {
    _placaController.dispose();
    _descricaoController.dispose();
    super.dispose();
  }

  Future<void> _enviar() async {
    FocusScope.of(context).unfocus();
    if (!_formKey.currentState!.validate()) return;

    setState(() => _enviando = true);
    try {
      await _api.criarDenuncia(
        usuarioId: widget.usuarioId,
        veiculoId: widget.veiculoId,
        placa: _placaController.text,
        tipo: _tipo,
        descricao: _descricaoController.text,
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Denúncia enviada. Obrigado por contribuir!')),
      );
      Navigator.pop(context);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(ApiService.mensagemDeErro(e))),
      );
    } finally {
      if (mounted) setState(() => _enviando = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Registrar denúncia')),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: const Color(0xFFEAF1F8),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: const Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Icon(Icons.shield_outlined, color: Color(0xFF1E3A5F), size: 26),
                      SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          'Ajude a comunidade a identificar possíveis fraudes e irregularidades. Informe os dados com clareza.',
                          style: TextStyle(color: Color(0xFF2B2B2B), height: 1.4),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 24),
                const Text('Placa do veículo', style: TextStyle(fontWeight: FontWeight.w600)),
                const SizedBox(height: 8),
                TextFormField(
                  controller: _placaController,
                  textCapitalization: TextCapitalization.characters,
                  maxLength: 8,
                  decoration: const InputDecoration(
                    hintText: 'ABC1D23',
                    prefixIcon: Icon(Icons.directions_car_outlined),
                    counterText: '',
                  ),
                  validator: (value) {
                    final placa = (value ?? '').replaceAll('-', '').trim();
                    if (placa.length < 7) return 'Informe uma placa válida.';
                    return null;
                  },
                ),
                const SizedBox(height: 18),
                const Text('Tipo de ocorrência', style: TextStyle(fontWeight: FontWeight.w600)),
                const SizedBox(height: 8),
                DropdownButtonFormField<String>(
                  value: _tipo,
                  decoration: const InputDecoration(prefixIcon: Icon(Icons.category_outlined)),
                  items: _tipos.entries
                      .map((item) => DropdownMenuItem(value: item.key, child: Text(item.value)))
                      .toList(),
                  onChanged: _enviando ? null : (value) {
                    if (value != null) setState(() => _tipo = value);
                  },
                ),
                const SizedBox(height: 18),
                const Text('Descreva o ocorrido', style: TextStyle(fontWeight: FontWeight.w600)),
                const SizedBox(height: 8),
                TextFormField(
                  controller: _descricaoController,
                  minLines: 5,
                  maxLines: 8,
                  maxLength: 1500,
                  decoration: const InputDecoration(
                    hintText: 'Conte o que aconteceu, quando ocorreu e outras informações relevantes.',
                    alignLabelWithHint: true,
                  ),
                  validator: (value) {
                    if ((value ?? '').trim().length < 20) {
                      return 'A descrição precisa ter pelo menos 20 caracteres.';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 10),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: _enviando ? null : _enviar,
                    icon: _enviando
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                          )
                        : const Icon(Icons.send_outlined),
                    label: Text(_enviando ? 'Enviando...' : 'Enviar denúncia'),
                  ),
                ),
                const SizedBox(height: 12),
                const Text(
                  'A denúncia será registrada como pendente para análise.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Color(0xFF6B7280), fontSize: 12),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
