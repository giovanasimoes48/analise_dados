import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

import '../models/documento.dart';
import '../models/manutencao.dart';
import '../models/usuario.dart';
import '../models/veiculo.dart';

class ApiService {
  /// Só preencha se for testar em CELULAR FÍSICO: coloque aqui o IP do seu PC
  /// na rede Wi-Fi (ex.: '192.168.0.10'). Nos outros casos deixe vazio.
  /// Pode ser informado na execução: --dart-define=API_HOST=192.168.0.10
  /// Deixe vazio para usar o endereço automático da plataforma.
  static const String apiHostManual = String.fromEnvironment('API_HOST');

  static String get _host {
    if (apiHostManual.isNotEmpty) return apiHostManual;
    // O emulador Android enxerga o PC pelo endereço especial 10.0.2.2
    if (!kIsWeb && defaultTargetPlatform == TargetPlatform.android) {
      return '10.0.2.2';
    }
    // Chrome (web) e Desktop: o backend roda na própria máquina
    return '127.0.0.1';
  }

  static String get baseUrl => 'http://$_host:5000/api';

  static const Map<String, String> _headers = {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
  };
  static const Duration _timeout = Duration(seconds: 10);
  static const String _msgSemServidor =
      'Não consegui falar com o servidor. Confira se o backend (app.py) '
      'está rodando e se o endereço da API está certo.';

  /// Tira o "Exception: " do começo para mostrar um texto limpo na tela.
  static String mensagemDeErro(Object erro) {
    return erro.toString().replaceFirst('Exception: ', '');
  }

  // ---------------------------------------------------------------- usuários

  Future<Usuario> login(String email, String senha) async {
    final response = await _post('/login', {
      'email': email.trim(),
      'senha': senha,
    });
    _check(response);
    return Usuario.fromJson(_corpo(response));
  }

  Future<Usuario> cadastrarUsuario({
    required String nome,
    required String email,
    required String telefone,
    required String senha,
  }) async {
    final response = await _post('/usuarios', {
      'nome': nome.trim(),
      'email': email.trim(),
      'telefone': telefone.trim(),
      // O backend recebe a senha digitada e é ele quem faz o hash.
      'senha': senha,
    });
    _check(response);
    return Usuario.fromJson(_corpo(response));
  }

  /// Passo 1 da recuperação de senha: pede o código para o e-mail informado.
  Future<String> solicitarRecuperacaoSenha(String email) async {
    final response = await _post('/recuperar-senha/solicitar', {
      'email': email.trim(),
    });
    _check(response);
    return _corpo(response)['message'].toString();
  }

  /// Passo 2: confere o código e grava a nova senha.
  Future<String> redefinirSenha({
    required String email,
    required String codigo,
    required String novaSenha,
  }) async {
    final response = await _post('/recuperar-senha/redefinir', {
      'email': email.trim(),
      'codigo': codigo.trim(),
      'nova_senha': novaSenha,
    });
    _check(response);
    return _corpo(response)['message'].toString();
  }

  Future<List<Usuario>> listarUsuarios() async {
    final response = await _get('/usuarios');
    _check(response);
    return (_corpo(response) as List)
        .map((item) => Usuario.fromJson(item))
        .toList();
  }

  // ---------------------------------------------------------------- veículos

  Future<List<Veiculo>> listarVeiculos() async {
    final response = await _get('/veiculos');
    _check(response);
    return (_corpo(response) as List)
        .map((item) => Veiculo.fromJson(item))
        .toList();
  }

  /// Só os veículos do usuário logado.
  Future<List<Veiculo>> listarVeiculosDoUsuario(int usuarioId) async {
    final todos = await listarVeiculos();
    return todos.where((v) => v.usuarioId == usuarioId).toList();
  }

  Future<List<Veiculo>> buscarVeiculos({
    String? marca,
    String? modelo,
    String ordem = 'modelo_asc',
  }) async {
    final params = <String, String>{'ordem': ordem};
    if (marca != null && marca.isNotEmpty) params['marca'] = marca;
    if (modelo != null && modelo.isNotEmpty) params['modelo'] = modelo;
    final response = await _get('/veiculos/busca', params);
    _check(response);
    return (_corpo(response) as List)
        .map((item) => Veiculo.fromJson(item))
        .toList();
  }

  Future<Veiculo> criarVeiculo(Map<String, dynamic> data) async {
    final response = await _post('/veiculos', data);
    _check(response);
    return Veiculo.fromJson(_corpo(response));
  }

  Future<void> atualizarVeiculo(int id, Map<String, dynamic> data) async {
    final response = await _enviar(
      () => http.put(
        _uri('/veiculos/$id'),
        headers: _headers,
        body: jsonEncode(data),
      ),
    );
    _check(response);
  }

  Future<void> deletarVeiculo(int id) async {
    final response = await _enviar(() => http.delete(_uri('/veiculos/$id')));
    _check(response);
  }

  // ------------------------------------------------- manutenções / documentos

  Future<List<Manutencao>> historicoManutencoes(int veiculoId) async {
    final response = await _get('/veiculos/$veiculoId/manutencoes');
    _check(response);
    return (_corpo(response) as List)
        .map((item) => Manutencao.fromJson(item))
        .toList();
  }

  Future<List<Documento>> proximosVencimentos() async {
    final response = await _get('/documentos/proximos-vencimentos');
    _check(response);
    return (_corpo(response) as List)
        .map((item) => Documento.fromJson(item))
        .toList();
  }

  // ---------------------------------------------------------------- denúncias

  Future<Map<String, dynamic>> criarDenuncia({
    required int usuarioId,
    int? veiculoId,
    required String placa,
    required String tipo,
    required String descricao,
  }) async {
    final dados = <String, dynamic>{
      'usuario_id': usuarioId,
      'placa': placa.trim().toUpperCase(),
      'tipo': tipo,
      'descricao': descricao.trim(),
    };
    if (veiculoId != null) dados['veiculo_id'] = veiculoId;
    final response = await _post('/denuncias', dados);
    _check(response);
    return _corpo(response) as Map<String, dynamic>;
  }

  // ------------------------------------------------------------- utilitários

  Uri _uri(String caminho, [Map<String, String>? query]) {
    return Uri.parse('$baseUrl$caminho').replace(queryParameters: query);
  }

  Future<http.Response> _get(String caminho, [Map<String, String>? query]) {
    return _enviar(() => http.get(_uri(caminho, query)));
  }

  Future<http.Response> _post(String caminho, Map<String, dynamic> corpo) {
    return _enviar(
      () => http.post(
        _uri(caminho),
        headers: _headers,
        body: jsonEncode(corpo),
      ),
    );
  }

  /// Faz a requisição e troca qualquer falha de rede (servidor desligado,
  /// IP errado, demora demais...) por uma mensagem que dá para entender.
  Future<http.Response> _enviar(
    Future<http.Response> Function() requisicao,
  ) async {
    try {
      return await requisicao().timeout(_timeout);
    } catch (_) {
      throw Exception(_msgSemServidor);
    }
  }

  dynamic _corpo(http.Response response) {
    return jsonDecode(utf8.decode(response.bodyBytes));
  }

  void _check(http.Response response) {
    if (response.statusCode >= 200 && response.statusCode < 300) return;

    String mensagem =
        'Não foi possível concluir a solicitação (erro ${response.statusCode}).';
    try {
      final data = _corpo(response);
      if (data is Map && data['error'] != null) {
        mensagem = data['error'].toString();
      }
    } catch (_) {
      // resposta que não é JSON (ex.: página de erro do Flask): fica a mensagem padrão
    }
    throw Exception(mensagem);
  }
}