# IntelligenceCar

Frontend desenvolvido em Flutter para consumir a API do IntelligenceCar.

## Como executar

1. Instale o Flutter.
2. Entre na pasta `frontend`.
3. Execute `flutter pub get`.
4. Confira o endereço da API em `lib/services/api_service.dart`.
5. Execute `flutter run`.

Para Android Emulator, a API local normalmente deve ser acessada por `10.0.2.2:5000`.
Para iOS Simulator ou execução em desktop, use `127.0.0.1:5000`.
Em um celular físico, use o IP da máquina que está executando o backend.

## Backend

Entre na pasta `backend`, configure o arquivo `.env` a partir de `.env.example`, instale as dependências e execute `python app.py`.

O banco deve ser criado usando `database/create_database.sql`.
## Diagrama de Classes

A estrutura de classes e o modelo de domínio do sistema IntelligenceCar foram mapeados com base nos modelos desenvolvidos no backend em Flask e na integração com o banco de dados MySQL.

### Estrutura do Domínio

O modelo está organizado em torno das seguintes entidades centrais:

- *User:* Representa os usuários cadastrados na plataforma. Mantém associação com as entidades de veículos e denúncias.
- *Veiculo:* Gerencia os dados dos veículos cadastrados na conta do usuário. Possui relação de composição com os registros de manutenção e de agregação com a documentação do veículo.
- *Manutencao:* Armazena os históricos de manutenção vinculados a um veículo específico.
- *Documento:* Concentra o controle de prazos e arquivos digitais associados ao veículo.
- *Denuncia:* Registra ocorrências e chamados abertos pelos usuários no sistema.

![Diagrama de Classes](docs/diagrama_de_classes.png)
![alt text](diagrama_de_classes.png)